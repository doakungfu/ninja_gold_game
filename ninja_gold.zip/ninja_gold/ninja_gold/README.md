A game where ninjas can earn gold by doing various activities at 4 different locations.
